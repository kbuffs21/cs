//
// 15 problems, 40 points
// 2 - rating 1
// 5 - rating 2
// 4 - rating 3
// 4 - rating 4

// rating 1
int tmin(void);
int test_tmin(void);
int minusOne(void);
int test_minusOne(void);
// rating 2
int evenBits(void);
int test_evenBits(void);
int divpwr2(int, int);
int test_divpwr2(int, int);
int isEqual(int, int);
int test_isEqual(int, int);
int negate(int);
int test_negate(int);
int getByte(int,int);
int test_getByte(int,int);
// rating 3
int isPositive(int);
int test_isPositive(int);
int addOK(int,int);
int test_addOK(int,int);
int isLessOrEqual(int,int);
int test_isLessOrEqual(int,int);
int logicalShift(int, int);
int test_logicalShift(int, int);
// rating 4
int leastBitPos(int);
int test_leastBitPos(int);
int bitParity(int);
int test_bitParity(int);
int isPower2(int);
int test_isPower2(int);
int bang(int);
int test_bang(int);
